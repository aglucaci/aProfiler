#!/usr/bin/env python
# -*- coding: utf-8 -*-

# =============================================================================
# Imports
# =============================================================================
#from AlignmentProfiler import *
import AlignmentProfiler as AP
import argparse
import os
import sys
import pathlib 

# =============================================================================
# Declares
# =============================================================================
parser = argparse.ArgumentParser(description='Process command line arguments')

parser.add_argument('--alignment', metavar='A', type=str, required=True,
                    help='Input multiple sequence alignment')
                    
parser.add_argument('--output', metavar='O', type=str, required=False,
                    help='Specify a location for the output CSV')

args = parser.parse_args()

#OutputDirectory = os.path.join("..", "..", "tables")
OutputDirectory = os.path.join("tables")

if args.output == None:
    OutputCSV = os.path.join(OutputDirectory,
                             os.path.basename(args.alignment) + "_output.csv")
else:
    OutputCSV = args.output
#end if

print("# Alignment file is:", args.alignment)
print("# Output will be saved to:", OutputCSV)

# =============================================================================
# Main
# =============================================================================
print()
print("#", "".join(["="]*78))
print("# Starting to profile multiple sequence alignment:", args.alignment)
print("#", "".join(["="]*78))
print()

if os.path.exists(args.alignment) and os.path.getsize(args.alignment) > 0:
    _MSA = AP.MSA_Process(args.alignment)
    print()
    print("# Loading complete on an alignment with", _MSA.NumSequences, "sequences, and", _MSA.NumCodonSites, "codon sites")
    print()
else:
    print("# ERROR: the file is either empty or does not exist")
#end if

# =============================================================================
# End of file
# =============================================================================
